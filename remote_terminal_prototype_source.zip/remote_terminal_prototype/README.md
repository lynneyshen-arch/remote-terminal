# Remote Terminal — communication prototype

Prototype scope: text request/reply between a Samsung GT-C3752 (MIDP 2.0 / CLDC 1.1)
and an Android companion app, using a small internet relay.

This is SOURCE CODE, not prebuilt JAR/APK binaries. The build environment used to
prepare this package did not contain Android SDK/Gradle or Java ME SDK libraries,
so no claim is made that binaries have been compiled or device-tested.

## Components

- `relay/relay.py`: Python 3 standard-library HTTP relay.
- `android/`: minimal Kotlin Android app. While open, it polls the relay for a
  Samsung request and lets you type a reply.
- `j2me/src/RemoteTerminal.java`: MIDP 2.0 MIDlet. It sends a request and polls
  for the Android reply.

## Important security warning

This prototype is for testing with non-sensitive text only.
The relay supports a bearer token, but the first version is plain HTTP to make
connectivity testing possible with the old Samsung browser/network stack.
HTTP does NOT encrypt traffic. Do not send passwords, private messages, Telegram
credentials, or personal data through a public HTTP relay. For real use, deploy
behind HTTPS with a certificate/cipher suite supported by the Samsung, or add
end-to-end encryption and a suitable key exchange before using private content.

Do not expose the relay publicly without changing the sample token and using
network restrictions/rate limits. The sample token is deliberately a placeholder.

## 1. Run the relay (local test)

Requires Python 3.10+.

```sh
cd relay
python relay.py
```

By default it listens on `0.0.0.0:8765`, token `CHANGE-ME-TO-A-LONG-RANDOM-TOKEN`.
Set environment variables before starting:

```sh
REMOTE_TERMINAL_TOKEN='your-long-random-token' PORT=8765 python relay.py
```

For phones hundreds of kilometres apart, the relay must run on an internet-reachable
server (VPS or suitable hosting). Running it only on a home PC behind a router
requires a secure tunnel/port forwarding; do not expose a plain HTTP port with
real personal data.

## 2. Android app

Open `android/` in Android Studio (current stable version). Let Gradle sync.
Set the relay base URL and the exact same token in the app's two fields.
For a first local connectivity test, the app permits cleartext HTTP. This is
intentionally prototype-only. Replace with HTTPS before real use.

The app polls only while its activity is open. Android battery/background
restrictions therefore do not affect this first test. A later version can use
a foreground service or push notifications.

## 3. Samsung MIDlet

Build `j2me/src/RemoteTerminal.java` with a Java ME SDK / Wireless Toolkit that
supports MIDP 2.0 and CLDC 1.1. Configure the base URL and token near the top
of the source before building.

The MIDlet uses `javax.microedition.io.Connector` and `HttpConnection`, with a small built-in UTF-8 form encoder (no Java SE `URLEncoder` dependency).
It sends `POST /ask` with URL-encoded UTF-8 text, then polls `GET /result?id=...`.
The JAR needs network permission on the phone.

The GT-C3752 has already shown reliable HTTP access to some sites, but this
prototype has not been tested on the handset. Its old TLS support is a known
uncertainty; this first test uses HTTP only and must not carry sensitive data.

## 4. Test sequence

1. Start the relay on a public test server.
2. Install/run the Android app and enter the relay URL and token.
3. Build/install the MIDlet on the Samsung.
4. Type `hello from Samsung` and send it.
5. The Android app should show the request.
6. Type a reply on Android and press Reply.
7. The Samsung should receive and display the reply.

If the Android app does not receive anything, check relay reachability, URL,
token, and whether the Android app is open. Do not troubleshoot Telegram,
browser, or maps until this basic round-trip works.

## Protocol

- `POST /ask` — Samsung submits `text=...`; returns `{"id":"..."}`
- `GET /next` — Android receives the oldest unanswered request, if any.
- `POST /reply` — Android submits `id=...&text=...`
- `GET /result?id=...` — Samsung checks whether its reply is ready.
- `GET /health` — relay health check (no auth).

All API endpoints except `/health` require `Authorization: Bearer <token>`.
