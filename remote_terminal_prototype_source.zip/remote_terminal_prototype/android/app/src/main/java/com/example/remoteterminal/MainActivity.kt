package com.example.remoteterminal

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import org.json.JSONObject
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var base: EditText
    private lateinit var token: EditText
    private lateinit var incoming: TextView
    private lateinit var reply: EditText
    private lateinit var status: TextView
    private var currentId: String = ""
    private val handler = Handler(Looper.getMainLooper())
    private var polling = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        base = EditText(this).apply {
            hint = "Relay URL, e.g. http://host:8765"
            setSingleLine(true)
            setText("http://YOUR-RELAY-HOST:8765")
        }
        token = EditText(this).apply {
            hint = "Relay bearer token"
            setSingleLine(true)
        }
        status = TextView(this).apply { text = "Enter relay URL and token." }
        incoming = TextView(this).apply {
            text = "No request yet."
            textSize = 18f
            setPadding(0, 24, 0, 24)
        }
        reply = EditText(this).apply { hint = "Type reply to Samsung" }
        val check = Button(this).apply {
            text = "Check for request"
            setOnClickListener { checkQueue() }
        }
        val send = Button(this).apply {
            text = "Send reply"
            setOnClickListener { sendReply() }
        }
        listOf(base, token, status, check, incoming, reply, send).forEach {
            layout.addView(it, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ))
        }
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun request(path: String, body: String? = null): String {
        val conn = (URL(base.text.toString().trim() + path).openConnection() as HttpURLConnection)
        try {
            conn.connectTimeout = 10000
            conn.readTimeout = 10000
            conn.setRequestProperty("Authorization", "Bearer " + token.text.toString())
            conn.setRequestProperty("Cache-Control", "no-store")
            if (body != null) {
                conn.requestMethod = "POST"
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
            return stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally { conn.disconnect() }
    }

    private fun checkQueue() {
        status.text = "Checking..."
        thread {
            try {
                val obj = JSONObject(request("/next"))
                runOnUiThread {
                    currentId = obj.optString("id")
                    if (currentId.isNotEmpty()) {
                        incoming.text = obj.optString("text")
                        status.text = "Request received."
                    } else {
                        incoming.text = "No pending request."
                        status.text = "Connected; queue empty."
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Error: ${e.message}" }
            }
        }
    }

    private fun sendReply() {
        if (currentId.isEmpty()) {
            status.text = "No request selected."
            return
        }
        status.text = "Sending reply..."
        val body = "id=" + enc(currentId) + "&text=" + enc(reply.text.toString())
        thread {
            try {
                request("/reply", body)
                runOnUiThread {
                    status.text = "Reply sent to relay."
                    currentId = ""
                    reply.setText("")
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Error: ${e.message}" }
            }
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
}
