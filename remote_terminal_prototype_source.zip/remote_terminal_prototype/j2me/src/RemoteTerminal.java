import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.io.*;
import java.io.*;
import java.util.*;

/**
 * Minimal MIDP 2.0 / CLDC 1.1 remote terminal prototype.
 * Change BASE_URL and TOKEN before building.
 */
public class RemoteTerminal extends MIDlet implements CommandListener {
    private static final String BASE_URL = "http://YOUR-RELAY-HOST:8765";
    private static final String TOKEN = "CHANGE-ME-TO-A-LONG-RANDOM-TOKEN";

    private Display display;
    private Form form;
    private TextField requestField;
    private StringItem status;
    private StringItem answer;
    private Command send = new Command("Send", Command.OK, 1);
    private Command back = new Command("Back", Command.BACK, 2);
    private boolean busy = false;

    public RemoteTerminal() {
        display = Display.getDisplay(this);
        form = new Form("Remote Terminal");
        requestField = new TextField("Search / message", "", 500, TextField.ANY);
        status = new StringItem("Status: ", "Ready");
        answer = new StringItem("Reply: ", "");
        form.append(requestField);
        form.append(status);
        form.append(answer);
        form.addCommand(send);
        form.addCommand(back);
        form.setCommandListener(this);
    }

    public void startApp() { display.setCurrent(form); }
    public void pauseApp() {}
    public void destroyApp(boolean unconditional) {}

    public void commandAction(Command c, Displayable d) {
        if (c == back) { notifyDestroyed(); return; }
        if (c == send && !busy) {
            final String text = requestField.getString();
            if (text == null || text.trim().length() == 0) {
                status.setText("Enter some text first.");
                return;
            }
            busy = true;
            status.setText("Sending...");
            answer.setText("");
            new Thread(new Runnable() {
                public void run() {
                    try {
                        String id = postForm("/ask", "text=" + enc(text), null);
                        id = extractJsonString(id, "id");
                        if (id == null || id.length() == 0) throw new IOException("No request ID");
                        setStatus("Waiting for Android...");
                        for (int i = 0; i < 60; i++) {
                            Thread.sleep(3000);
                            String result = get("/result?id=" + enc(id));
                            if (result.indexOf("\"ready\":true") >= 0) {
                                String reply = extractJsonString(result, "text");
                                setAnswer(reply == null ? "(empty reply)" : reply);
                                setStatus("Reply received.");
                                busy = false;
                                return;
                            }
                        }
                        setStatus("Timed out. Try again.");
                    } catch (Exception e) {
                        setStatus("Connection error: " + e.toString());
                    }
                    busy = false;
                }
            }).start();
        }
    }


    private void setStatus(final String value) {
        display.callSerially(new Runnable() {
            public void run() { status.setText(value); }
        });
    }

    private void setAnswer(final String value) {
        display.callSerially(new Runnable() {
            public void run() { answer.setText(value); }
        });
    }

    private String enc(String s) throws Exception {
        byte[] bytes = s.getBytes("UTF-8");
        StringBuffer out = new StringBuffer();
        for (int i = 0; i < bytes.length; i++) {
            int v = bytes[i] & 0xff;
            if ((v >= 'a' && v <= 'z') || (v >= 'A' && v <= 'Z') ||
                (v >= '0' && v <= '9') || v == '-' || v == '_' ||
                v == '.' || v == '*') {
                out.append((char)v);
            } else if (v == ' ') {
                out.append('+');
            } else {
                out.append('%');
                final char[] hex = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
                char hi = hex[(v >> 4) & 15];
                char lo = hex[v & 15];
                out.append(hi);
                out.append(lo);
            }
        }
        return out.toString();
    }

    private String postForm(String path, String data, String unused) throws IOException {
        HttpConnection c = null;
        OutputStream os = null;
        InputStream is = null;
        try {
            c = (HttpConnection)Connector.open(BASE_URL + path);
            c.setRequestMethod(HttpConnection.POST);
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            c.setRequestProperty("Authorization", "Bearer " + TOKEN);
            os = c.openOutputStream();
            os.write(data.getBytes("UTF-8"));
            os.flush();
            is = c.openInputStream();
            return readAll(is);
        } finally {
            try { if (is != null) is.close(); } catch (Exception e) {}
            try { if (os != null) os.close(); } catch (Exception e) {}
            try { if (c != null) c.close(); } catch (Exception e) {}
        }
    }

    private String get(String path) throws IOException {
        HttpConnection c = null;
        InputStream is = null;
        try {
            c = (HttpConnection)Connector.open(BASE_URL + path);
            c.setRequestMethod(HttpConnection.GET);
            c.setRequestProperty("Authorization", "Bearer " + TOKEN);
            is = c.openInputStream();
            return readAll(is);
        } finally {
            try { if (is != null) is.close(); } catch (Exception e) {}
            try { if (c != null) c.close(); } catch (Exception e) {}
        }
    }

    private String readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] b = new byte[256];
        int n;
        while ((n = in.read(b)) != -1) out.write(b, 0, n);
        return new String(out.toByteArray(), "UTF-8");
    }

    // Tiny JSON string extractor for this relay's controlled response format.
    private String extractJsonString(String json, String key) {
        String marker = "\"" + key + "\":\"";
        int p = json.indexOf(marker);
        if (p < 0) return null;
        p += marker.length();
        StringBuffer out = new StringBuffer();
        boolean esc = false;
        for (int i = p; i < json.length(); i++) {
            char ch = json.charAt(i);
            if (esc) {
                if (ch == 'n') out.append('\n');
                else if (ch == 'r') out.append('\r');
                else out.append(ch);
                esc = false;
            } else if (ch == '\\') esc = true;
            else if (ch == '"') return out.toString();
            else out.append(ch);
        }
        return null;
    }
}
