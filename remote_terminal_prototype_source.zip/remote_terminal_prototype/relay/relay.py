#!/usr/bin/env python3
"""Tiny in-memory relay for the Remote Terminal prototype. Python stdlib only."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs
from collections import deque
import json, os, secrets, time

TOKEN = os.environ.get("REMOTE_TERMINAL_TOKEN", "CHANGE-ME-TO-A-LONG-RANDOM-TOKEN")
HOST = os.environ.get("HOST", "0.0.0.0")
PORT = int(os.environ.get("PORT", "8765"))
requests = {}
queue = deque()

class Handler(BaseHTTPRequestHandler):
    server_version = "RemoteTerminalRelay/0.1"

    def log_message(self, fmt, *args):
        # Avoid logging submitted message bodies.
        print("%s - %s" % (self.address_string(), fmt % args))

    def send_json(self, code, obj):
        data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def authorized(self):
        return self.headers.get("Authorization", "") == "Bearer " + TOKEN

    def body_fields(self):
        n = int(self.headers.get("Content-Length", "0"))
        if n < 0 or n > 8192:
            raise ValueError("invalid body size")
        raw = self.rfile.read(n).decode("utf-8", "replace")
        return parse_qs(raw, keep_blank_values=True)

    def do_GET(self):
        if self.path == "/health":
            return self.send_json(200, {"ok": True, "service": "remote-terminal-relay"})
        if not self.authorized():
            return self.send_json(401, {"error": "unauthorized"})
        if self.path == "/next":
            while queue:
                rid = queue.popleft()
                item = requests.get(rid)
                if item and item["reply"] is None and not item["claimed"]:
                    item["claimed"] = True
                    return self.send_json(200, {"id": rid, "text": item["text"]})
            return self.send_json(200, {"id": "", "text": ""})
        if self.path.startswith("/result?"):
            from urllib.parse import urlparse
            q = parse_qs(urlparse(self.path).query)
            rid = (q.get("id") or [""])[0]
            item = requests.get(rid)
            if not item:
                return self.send_json(404, {"error": "unknown request"})
            if item["reply"] is None:
                return self.send_json(200, {"ready": False, "text": ""})
            return self.send_json(200, {"ready": True, "text": item["reply"]})
        return self.send_json(404, {"error": "not found"})

    def do_POST(self):
        if not self.authorized():
            return self.send_json(401, {"error": "unauthorized"})
        try:
            fields = self.body_fields()
        except Exception:
            return self.send_json(400, {"error": "bad request"})
        if self.path == "/ask":
            text = (fields.get("text") or [""])[0][:1500]
            if not text.strip():
                return self.send_json(400, {"error": "empty request"})
            rid = secrets.token_urlsafe(9)
            requests[rid] = {"text": text, "reply": None, "claimed": False,
                             "created": time.time()}
            queue.append(rid)
            return self.send_json(200, {"id": rid})
        if self.path == "/reply":
            rid = (fields.get("id") or [""])[0]
            text = (fields.get("text") or [""])[0][:1500]
            item = requests.get(rid)
            if not item:
                return self.send_json(404, {"error": "unknown request"})
            item["reply"] = text
            return self.send_json(200, {"ok": True})
        return self.send_json(404, {"error": "not found"})

if __name__ == "__main__":
    if TOKEN == "CHANGE-ME-TO-A-LONG-RANDOM-TOKEN":
        print("WARNING: using placeholder token; set REMOTE_TERMINAL_TOKEN before public use.")
    print(f"Remote Terminal relay listening on {HOST}:{PORT}")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
